package com.example.mycalculator;

public class Calculator {
    private double valueOne = Double.NaN;
    private double valueTwo;
    private String currentAction;

    public void setValueOne(double value) {
        this.valueOne = value;
    }

    public void setValueTwo(double value) {
        this.valueTwo = value;
    }

    public void setAction(String action) {
        this.currentAction = action;
    }

    public double calculate() {
        switch (currentAction) {
            case "+":
                return valueOne + valueTwo;
            case "-":
                return valueOne - valueTwo;
            case "*":
                return valueOne * valueTwo;
            case "/":
                if (valueTwo != 0) {
                    return valueOne / valueTwo;
                } else {
                    throw new ArithmeticException("Cannot divide by zero");
                }
            default:
                return valueTwo; // Return valueTwo if no action is set
        }
    }
}
